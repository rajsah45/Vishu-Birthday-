const intro = document.getElementById("intro");
const main = document.getElementById("main");
const giftButton = document.getElementById("giftButton");
const typed = document.getElementById("typedMessage");
const letterButton = document.getElementById("letterButton");
const secretLetter = document.getElementById("secretLetter");
const celebrateButton = document.getElementById("celebrateButton");
const finalText = document.getElementById("finalText");
const toast = document.getElementById("toast");

const message =
"Today is more than just a date on the calendar. It is a reminder of how special your presence is. I hope this new year of your life brings you confidence, laughter, exciting opportunities and countless reasons to smile. Happy Birthday! 🎂✨";

giftButton.addEventListener("click", () => {
  giftButton.style.transform = "scale(1.25) rotate(4deg)";
  burstAt(window.innerWidth / 2, window.innerHeight / 2, ["✨","💖","🎉","⭐"]);

  setTimeout(() => {
    intro.style.opacity = "0";
    intro.style.transform = "scale(1.08)";
  }, 350);

  setTimeout(() => {
    intro.style.display = "none";
    main.classList.remove("hidden");
    window.scrollTo({top:0,behavior:"instant"});
    typeMessage();
    startParticles();
  }, 1000);
});

function typeMessage() {
  let i = 0;
  typed.textContent = "";

  const timer = setInterval(() => {
    typed.textContent += message[i];
    i++;
    if (i >= message.length) clearInterval(timer);
  }, 28);
}

letterButton.addEventListener("click", () => {
  secretLetter.classList.toggle("show");
  letterButton.textContent =
    secretLetter.classList.contains("show")
      ? "💖 Close the message"
      : "Open your special message";

  burstAt(window.innerWidth / 2, window.innerHeight * .55, ["💌","💖","✨"]);
});

celebrateButton.addEventListener("click", () => {
  finalText.textContent = "Your wish is on its way... make it a good one! 🌟";
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2600);

  for (let i = 0; i < 7; i++) {
    setTimeout(() => {
      const x = 15 + Math.random() * 70;
      const y = 25 + Math.random() * 45;
      burstAt(window.innerWidth * x / 100, window.innerHeight * y / 100,
        ["🎉","✨","💖","🥳","⭐","🎊"]);
    }, i * 180);
  }
});

function burstAt(x, y, emojis) {
  for (let i = 0; i < 24; i++) {
    const el = document.createElement("div");
    el.className = "burst";
    el.textContent = emojis[Math.floor(Math.random() * emojis.length)];
    el.style.left = x + "px";
    el.style.top = y + "px";
    document.body.appendChild(el);

    const angle = Math.random() * Math.PI * 2;
    const distance = 60 + Math.random() * 190;
    const dx = Math.cos(angle) * distance;
    const dy = Math.sin(angle) * distance;

    const animation = el.animate(
      [
        { transform: "translate(-50%,-50%) scale(.4)", opacity: 1 },
        { transform: `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px)) scale(1)`, opacity: 0 }
      ],
      { duration: 900 + Math.random() * 700, easing: "cubic-bezier(.2,.8,.3,1)" }
    );
    animation.onfinish = () => el.remove();
  }
}

function startParticles() {
  const holder = document.getElementById("particles");
  const symbols = ["✦","·","✧","⋆","•"];

  setInterval(() => {
    if (document.hidden) return;
    const p = document.createElement("span");
    p.className = "particle";
    p.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    p.style.left = Math.random() * 100 + "vw";
    p.style.fontSize = (8 + Math.random() * 12) + "px";
    p.style.animationDuration = (5 + Math.random() * 6) + "s";
    holder.appendChild(p);
    setTimeout(() => p.remove(), 12000);
  }, 350);
}
